package com.natasaandzic.hydratabletopgames.model;

public class Keys {

	public static final String KEY_EVENTS = "Sheet1";
	public static final String KEY_EVENTNAME = "Naziv";
	public static final String KEY_EVENTDATE = "Datum";
	public static final String KEY_EVENTTIME = "Vreme";
	public static final String KEY_EVENTDAY = "Dan";
	public static final String KEY_EVENTDESCRIPTION = "Opis";

	public static final String KEY_GAMES = "Sheet1";
	public static final String KEY_GAMENAME = "Naziv";
	public static final String KEY_GAMEPRICE = "Cena";
	public static final String KEY_GAMEDESCRIPTION = "Opis";
	public static final String KEY_GAMEGENRE = "Zanr";


}