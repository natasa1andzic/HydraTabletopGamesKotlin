package com.natasaandzic.hydratabletopgames.firebase;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.natasaandzic.hydratabletopgames.R;

public class FirebaseActivity extends AppCompatActivity {


}
